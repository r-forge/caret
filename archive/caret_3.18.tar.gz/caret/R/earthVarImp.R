# evimp.R

get.used.preds <- function(obj)   # obj is an earth object
{ 
    which(apply(obj$dirs[obj$selected.terms,,drop=FALSE],2,any))
}

evimp <- function(obj, details=FALSE)
{
    earth:::check.classname(obj, deparse(substitute(x)), "earth")
    dirs <- obj$dirs
    nsubsets <- length(obj$selected.terms)
    crit.strings <- c("nsubsets", "gcv", "rss")
    ncrits <- length(crit.strings)
    pred.names <- colnames(dirs)

    # tagged.pred.names is a copy of pred.names but with unused 
    # predictors renamed by adding a "-unused" suffix.
    # By unused, we mean unused in the final model.

    tagged.pred.names <- pred.names
    unused.preds <- rep(TRUE, times=length(pred.names))
    unused.preds[get.used.preds(obj)] <- FALSE
    tagged.pred.names[unused.preds] <- 
        paste(tagged.pred.names[unused.preds], "-unused", sep="")

    # delta[isubset, icrit] is the change in criteria value 
    # for isubset using criteria icrit

    stopifnot(nsubsets >= 1)
    deltas <- matrix(nrow=nsubsets-1, ncol=ncrits)
    colnames(deltas) <- crit.strings
    deltas[,"nsubsets"] <- rep(1, times=nsubsets-1)
    deltas[,"gcv"]      <- -diff(obj$gcv.per.subset[1:nsubsets])
    deltas[,"rss"]      <- -diff(obj$rss.per.subset[1:nsubsets])

    # preds.in.each.term[iterm] is the indices of predictors in term iterm

    preds.in.each.term <- apply(obj$dirs, 1, function(row) which(row != 0))

    # importances[ipred, icrit] is the importance value for ipred 
    # using criteria icrit.
    # The "importance value" is the sum of deltas for each predictor for all terms 
    # that use the predictor.

    importances <- matrix(0, nrow=length(pred.names), ncol=ncrits)
    colnames(importances) <- colnames(deltas)
    rownames(importances) <- pred.names

    if (nsubsets > 1) for(isubset in 2:nsubsets) {
        terms.in.this.subset <- obj$prune.terms[isubset,-1]  # -1 drops intercept
        preds.in.this.subset <- unique(unlist(preds.in.each.term[terms.in.this.subset]))

        # cat("isubset", isubset, "terms.in.this.subset", terms.in.this.subset, 
        #         "preds.in.this.subset", preds.in.this.subset, 
        #         "crit", deltas[isubset-1,2],
        #          "\n")

        for (icrit in 1:ncrits)
            importances[preds.in.this.subset, icrit] <- 
                importances[preds.in.this.subset, icrit] + 
                deltas[isubset-1, icrit]
    }
    pred.tab <- matrix(0, nrow=length(pred.names), ncol=ncrits)
    colnames(pred.tab) <- colnames(deltas)

    for(icrit in 1:ncrits) {
        # sort this column in pred.tab by importances for this column

        pred.tab[,icrit] <- 
            tagged.pred.names[order(importances[,icrit], decreasing=TRUE)]

        # normalize all importances except nsubsets

        if (icrit > 1) {
            max. <- max(importances[,icrit])
            if (max. != 0)
                importances[,icrit] <- importances[,icrit] / max.
        }
    }
    if (details)
        list(importances=pred.tab, values=importances)
    else
        pred.tab
}


varImp.earth <- function(object, value = "gcv", ...)
{

  library(earth)
  out <- evimp(object, details = TRUE)$values[,value, drop = FALSE]
  colnames(out) <- "Overall"
  as.data.frame(out)

}

