### Name: trainNWS
### Title: Fit Predictive Models over Different Tuning Parameters
### Aliases: trainNWS
### Keywords: models

### ** Examples

## Not run: 
##D data(iris)
##D TrainData <- iris[,1:4]
##D TrainClasses <- iris[,5]
##D 
##D knnFit <- trainNWS(TrainData, TrainClasses, "knn", tuneLength = 10,
##D    trControl = trainNWSControl(method = "boot"))
## End(Not run)



